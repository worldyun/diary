package com.edu.notebook.service.impl;

import com.edu.notebook.domain.UserMapper;
import com.edu.notebook.pojo.ReturnResult;
import com.edu.notebook.pojo.User;
import com.edu.notebook.service.UserService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

@Service
public class UserServiceImpl implements UserService {
    @Resource
    private UserMapper userMapper;
    @Override
    public User findByUsername(String username) {
        User user = userMapper.findByUsername(username);
        return user;
    }

    @Override
    public ReturnResult addUsername(User user) {
        ReturnResult result = new ReturnResult();
        if(findByUsername(user.getUsername())!=null){
            result.setStatus(102);
            result.setMsg("注册失败,用户名重复");
            return result;
        }
        try {
            userMapper.addUsername(user);
            result.setStatus(101);
            result.setMsg("注册成功");

        }catch (Exception e){
            //用户名重复
            result.setStatus(103);
            result.setMsg("服务器错误/未知错误");

        }
        return  result;
    }

    @Override
    public ReturnResult logIn(User user, HttpSession session) {
        ReturnResult result = new ReturnResult();
        try {
            User dataUser = findByUsername(user.getUsername());
            if(dataUser==null){
                result.setStatus(202);
                result.setMsg("用户名不存在");
                return result;
            }
            if(dataUser.getPassword().equals(user.getPassword())&&
                    dataUser.getUsername().equals(user.getUsername())){
                result.setStatus(201);
                result.setMsg("登录成功");
                session.setAttribute("user",dataUser);
            }
            else {
                result.setStatus(203);
                result.setMsg("密码错误");
            }
        }catch (Exception e){
            result.setStatus(204);
            result.setMsg("服务器错误/未知错误");
        }
        return result;
    }
}
