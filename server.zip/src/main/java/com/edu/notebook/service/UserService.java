package com.edu.notebook.service;

import com.edu.notebook.pojo.ReturnResult;
import com.edu.notebook.pojo.User;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpSession;


public interface UserService {
    @Transactional
    User findByUsername(String username);
    @Transactional
    ReturnResult addUsername(User user);
    @Transactional
    ReturnResult logIn(User user, HttpSession session);
}
