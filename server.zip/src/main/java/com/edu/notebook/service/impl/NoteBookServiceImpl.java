package com.edu.notebook.service.impl;

import com.edu.notebook.domain.NoteBookMapper;
import com.edu.notebook.domain.UserMapper;
import com.edu.notebook.pojo.NoteBook;
import com.edu.notebook.pojo.NoteBookResult;
import com.edu.notebook.pojo.ReturnResult;
import com.edu.notebook.service.NoteBookService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class NoteBookServiceImpl implements NoteBookService {
    @Resource
    private NoteBookMapper noteBookMapper;
    @Override
    public ReturnResult addBook(int uid,int timestamp,String data) {
        ReturnResult result = new ReturnResult();
        try {
            noteBookMapper.addNoteBook(uid,timestamp,data);
            result.setStatus(401);
            result.setMsg("新建成功");
        }catch (Exception e){
            result.setStatus(402);
            result.setMsg("服务器错误/未知错误");
        }
        return result;
    }

    @Override
    public NoteBookResult getNoteBook(int uid, int page, int endtimestamp, int starttimestamp) {
        NoteBookResult result = new NoteBookResult();
        try {
            List<NoteBook> books = noteBookMapper.getNoteBookByUid(uid, (page-1)*20, endtimestamp, starttimestamp);
            result.setStatus(501);
            result.setMsg("查询成功");
            result.setDiarys(books);
        }catch (Exception e){
            System.out.println(e);
            result.setStatus(502);
            result.setMsg("服务器错误/未知错误");
        }
        return result;
    }

    @Override
    public ReturnResult deleteBook(int uid, int did) {
        NoteBook book = noteBookMapper.findByUidAndDid(uid, did);
        ReturnResult result = new ReturnResult();
        if(book==null){
            result.setStatus(602);
            result.setMsg("无权限");
            return result;
        }
        try {
            noteBookMapper.deleteBookByDid(did);
            result.setStatus(601);
            result.setMsg("删除成功");

        }catch (Exception e){
            System.out.println(e);
            result.setMsg("服务器错误/未知错误");
            result.setStatus(603);
        }


        return result;
    }
}
