package com.edu.notebook.service;

import com.edu.notebook.pojo.NoteBookResult;
import com.edu.notebook.pojo.ReturnResult;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


public interface NoteBookService {
    @Transactional
    public ReturnResult addBook(int uid,int timestamp,String data);
    @Transactional
    public NoteBookResult getNoteBook(int uid,int page, int endtimestamp, int starttimestamp);
    @Transactional
    public ReturnResult deleteBook(int uid,int did);
}
