package com.edu.notebook.domain;

import com.edu.notebook.pojo.NoteBook;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Scope("prototype")
public interface NoteBookMapper {
    @Insert("insert into notebook(uid,timestamp,data) values(${uid},${timestamp},'${data}')")
    void addNoteBook(int uid,int timestamp,String data);
    @Select("select * from notebook where uid = ${uid} and timestamp < ${endtimestamp} and " +
            " timestamp > ${starttimestamp} order by did desc limit ${curPage},20")
    List<NoteBook> getNoteBookByUid(int uid, int curPage,int endtimestamp, int starttimestamp);
    @Select("select * from notebook where uid = ${uid} and did =${did}")
    NoteBook findByUidAndDid(int uid,int did);
    @Delete("delete from notebook where did = ${did}")
    void deleteBookByDid(int did);
}
