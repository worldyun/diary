package com.edu.notebook.domain;

import com.edu.notebook.pojo.User;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

@Repository
@Scope("prototype")
public interface UserMapper {
    @Select("select * from user where username='${username}'")
    User findByUsername(String username);
    @Insert("insert into user(username,password) values('${username}','${password}')")
    void addUsername(User user);

}
