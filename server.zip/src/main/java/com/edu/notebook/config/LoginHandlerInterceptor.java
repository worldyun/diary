package com.edu.notebook.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@Configuration
public class LoginHandlerInterceptor implements HandlerInterceptor {
    @Override

    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        response.setContentType("application/json;charset=utf8");
            if(response.getStatus()==404){
            String result = "{\"status\":404,\"msg\":\"不存在该页面\"}";
            response.getWriter().println(result);
            return false;
            }
            if(response.getStatus()==400){
                response.setStatus(200);
                String result = "{\"status\":2,\"msg\":\"参数异常\"}";
                response.getWriter().println(result);
                return false;

            }
        Object username = request.getSession().getAttribute("user");
        if(username!=null){
            return true;
        }
        String result = "{\"status\":1,\"msg\":\"未登录\"}";
        response.getWriter().println(result);
        return false;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {

    }
}
