package com.edu.notebook.pojo;

import java.util.List;

public class NoteBookResult {
    private int status;
    private String msg;
    private List<NoteBook> diarys;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public List<NoteBook> getDiarys() {
        return diarys;
    }

    public void setDiarys(List<NoteBook> diarys) {
        this.diarys = diarys;
    }
}
