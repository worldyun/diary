package com.edu.notebook.controller;

import com.edu.notebook.pojo.NoteBookResult;
import com.edu.notebook.pojo.ReturnResult;
import com.edu.notebook.pojo.User;
import com.edu.notebook.service.NoteBookService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

@RestController
public class NoteBookController {
    @Resource
    private NoteBookService noteBookService;
    @RequestMapping("/add")
    public ReturnResult addBook( @RequestParam("data")String data,  @RequestParam("timestamp")int timestamp, HttpSession session){
        User user =(User)session.getAttribute("user");
        return noteBookService.addBook(user.getUid(), timestamp,data);
    }
    @RequestMapping("/get")
    public NoteBookResult getNoteBook(@RequestParam("page")int page, @RequestParam("endtimestamp")int endtimestamp,
                                      @RequestParam("starttimestamp") int starttimestamp, HttpSession session){
        User user =(User)session.getAttribute("user");
        return noteBookService.getNoteBook(user.getUid(),page,
                endtimestamp,starttimestamp);

    }
    @RequestMapping("/del")
    public ReturnResult deleteBook(@RequestParam("did") int did,HttpSession session){
        User user =(User)session.getAttribute("user");
        return noteBookService.deleteBook(user.getUid(), did);
    }

}
