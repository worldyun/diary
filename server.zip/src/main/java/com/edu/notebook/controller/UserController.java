package com.edu.notebook.controller;

import com.edu.notebook.pojo.ReturnResult;
import com.edu.notebook.pojo.User;
import com.edu.notebook.service.UserService;
import org.apache.ibatis.javassist.expr.NewArray;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

@RestController

public class UserController {
    @Resource
    private UserService userService;
    @RequestMapping("/signup")
    public ReturnResult signUp(@RequestParam("username") String username,@RequestParam("password")String password){
        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        return userService.addUsername(user);
    }
    @RequestMapping("/signin")
    public ReturnResult signIn(@RequestParam("username")String username, @RequestParam("password")String password, HttpSession session){
        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        return userService.logIn(user,session);
    }
    @RequestMapping("/signout")
    public void signOut( HttpSession session){
        session.removeAttribute("user");
    }
    @RequestMapping("/refreshSession")
    public void updateSession(HttpSession session){
        Object user = session.getAttribute("user");
        session.setAttribute("user", user);
    }

}
